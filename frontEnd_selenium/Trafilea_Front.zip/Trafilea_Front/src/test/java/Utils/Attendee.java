package Utils;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.Browser;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.Duration;
import java.util.Properties;
import enums.*;



public class Attendee {

    private static Attendee attendee;
    private static String OS = System.getProperty("os.name").toLowerCase();
    public static boolean IS_WINDOWS = (OS.indexOf("win") >= 0);
    public static WebDriver driver;
    private static Properties properties;



    /*public Attendee() {
        // Cargar el archivo de propiedades desde el classpath
        InputStream inputStream = Attendee.class.getClassLoader().getResourceAsStream("config.properties");

        properties = new Properties();
        try {
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/

    public Attendee() {
        // Cargar el archivo de propiedades desde el classpath
        InputStream inputStream = Attendee.class.getClassLoader().getResourceAsStream("config.properties");

        properties = new Properties();
        try {
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Inicializar el controlador
        String browser = properties.getProperty("trafilea.driver.browser");
        boolean headless = Boolean.parseBoolean(properties.getProperty("trafilea.driver.headless"));
        driver = configBrowser(browser, headless);
    }


    public static WebDriver getDriver() {
        return driver;
    }


    /*public static Attendee getInstance() {
        if (attendee == null) {
            attendee = new Attendee();
        }
        return attendee;
    }*/
    public static synchronized Attendee getInstance() {
        if (attendee == null) {
            attendee = new Attendee();
            // Inicializar el controlador aquí
            String browser = properties.getProperty("trafilea.driver.browser");
            boolean headless = Boolean.parseBoolean(properties.getProperty("trafilea.driver.headless"));
            driver = attendee.configBrowser(browser, headless);
        }
        return attendee;
    }


    public static void openPage(String url) {
        driver.get(url);
    }

    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public WebDriver configBrowser(String browser, boolean headless) {
        WebDriver driver = null;
        ChromeOptions chromeOptions = new ChromeOptions();
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        EdgeOptions edgeOptions = new EdgeOptions();
        InternetExplorerOptions ieOptions = new InternetExplorerOptions();

        String implicitWaitSecondsString = properties.getProperty("trafilea.implicit.wait");
        long implicitWaitSeconds = Long.parseLong(implicitWaitSecondsString);
        Duration implicitWaitDuration = Duration.ofSeconds(implicitWaitSeconds);


        if (IS_WINDOWS) {
            switch (browser.toLowerCase()) {
                case "chrome":
                    WebDriverManager chromedriver = WebDriverManager.chromedriver();
                    chromedriver.browserVersion("90");
                    chromedriver.setup();
                    chromeOptions.addArguments("--start-maximized", "--enable-automation", "--no-sandbox", "--disable-infobars",
                            "--disable-dev-shm-usage", "--disable-browser-side-navigation", "--disable-gpu", "--remote-allow-origins=*");
                    if (headless)
                        chromeOptions.addArguments("--headless");
                    driver = new ChromeDriver(chromeOptions);
                    break;
                case "firefox":
                    WebDriverManager.firefoxdriver().arch64().setup();
                    firefoxOptions.addArguments("--start-maximized", "--enable-automation", "--disable-infobars",
                            "--disable-browser-side-navigation", "--disable-gpu", "--remote-allow-origins=*");
                    if (headless)
                        firefoxOptions.addArguments("--headless");
                    driver = new FirefoxDriver(firefoxOptions);
                    break;
                case "edge":
                    WebDriverManager.edgedriver().setup();
                    edgeOptions.addArguments("--start-maximized", "--enable-automation", "--no-sandbox", "--disable-infobars",
                            "--disable-dev-shm-usage", "--disable-browser-side-navigation", "--disable-gpu", "--remote-allow-origins=*");
                    if (headless)
                        edgeOptions.addArguments("--headless");
                    driver = new EdgeDriver(edgeOptions);
                    break;
                case "ie":
                    WebDriverManager.iedriver().setup();
                    ieOptions.destructivelyEnsureCleanSession();
                    ieOptions.requireWindowFocus();
                    ieOptions.setAcceptInsecureCerts(true);
                    ieOptions.takeFullPageScreenshot();
                    ieOptions.ignoreZoomSettings();
                    ieOptions.setCapability("disable-popup-blocking", true);
                    driver = new InternetExplorerDriver(ieOptions);
                    break;
            }
        } else {
            switch (browser.toLowerCase()) {
                case "chromium":
                    driver = WebDriverManager.chromiumdriver().create();
                    break;
                case "chrome":
                    WebDriverManager.chromedriver().browserVersion("121.0.6167.85").arch64().setup();
                    chromeOptions.addArguments("--start-maximized", "--enable-automation", "--no-sandbox", "--disable-infobars",
                            "--disable-dev-shm-usage", "--disable-browser-side-navigation", "--disable-gpu", "--remote-allow-origins=*");
                    if (headless)
                        chromeOptions.addArguments("--headless");
                    driver = new ChromeDriver(chromeOptions);
                    break;
                case "firefox":
                    WebDriverManager.firefoxdriver().arch64().setup();
                    firefoxOptions.addArguments("--start-maximized", "--enable-automation", "--disable-infobars",
                            "--disable-browser-side-navigation", "--disable-gpu", "--remote-allow-origins=*");
                    if (headless)
                        firefoxOptions.addArguments("--headless");
                    driver = new FirefoxDriver(firefoxOptions);
                    break;
                case "safari":
                    WebDriverManager.safaridriver().arch64().setup();
                    SafariOptions safariOptions = new SafariOptions();
                    safariOptions.setAcceptInsecureCerts(true);
                    safariOptions.setAutomaticInspection(true);
                    safariOptions.setCapability("disable-popup-blocking", true);
                    driver = new SafariDriver(safariOptions);
                    break;
            }
        }

        if (driver != null) {
            driver.manage().timeouts().implicitlyWait(implicitWaitDuration);
            driver.manage().window().maximize();
        }
        return driver;
    }



}
