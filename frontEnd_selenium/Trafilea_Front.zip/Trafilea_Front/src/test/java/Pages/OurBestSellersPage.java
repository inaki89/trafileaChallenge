package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OurBestSellersPage extends BasePage {

    @FindBy(xpath = "//*[@id=\"buyContainer\"]/div[2]/div/button")
    private WebElement btn_AddCar;
    @FindBy(xpath = "//*[@id=\"__next\"]/div/div[3]/div[1]/div/div[2]/div/div[3]/button")
    private WebElement btn_checkOut;
    @FindBy(xpath = "//*[@id=\"emailSection\"]/div[2]/div[1]/div/div/input")
    private WebElement e_mail;
    @FindBy(xpath = "//*[@id=\"deliveryAddressSection\"]/div[2]/div/div[1]/div/div/input")
    private WebElement nombre;
    @FindBy(xpath = "//*[@id=\"deliveryAddressSection\"]/div[2]/div/div[2]")
    private WebElement apellido;
    @FindBy(xpath = "//*[@id=\"deliveryAddressSection\"]/div[2]/div/div[3]")
    private WebElement direccion;
    @FindBy(xpath = "//*[@id=\"deliveryAddressSection\"]/div[2]/div/div[4]")
    private WebElement opcional;
    @FindBy(xpath = "//*[@id=\"deliveryAddressSection\"]/div[2]/div/div[6]")
    private WebElement zip;
    @FindBy(xpath = "//*[@id=\"deliveryAddressSection\"]/div[2]/div/div[8]/div/div/input")
    private WebElement cuidad;
    @FindBy(xpath = "//*[@id=\"deliveryAddressSection\"]/div[2]/div/div[9]/div/div/input")
    private WebElement telefono;
    @FindBy(xpath = "//*[@id=\"root\"]/form/span[2]/div/div/div[2]/span/input")
    private WebElement numTarjeta;
    @FindBy(xpath = "//*[@id=\"__next\"]/div/div/div[1]/div/div[8]/div/div/div[2]/div[1]/div[2]/div/div[2]/div/div/input")
    private WebElement nombreTarjeta;
    @FindBy(xpath = "//*[@id=\"root\"]/form/span[2]/div/span/input")
    private WebElement vencimientoTarjeta;

    public  void completaCompra(){
        click(e_mail);
        click(apellido);
        click(direccion);
        click(opcional);

        click(zip);

        click(cuidad);

        click(telefono);

        click(numTarjeta);

        click(nombreTarjeta);

        click(vencimientoTarjeta);

    }

}
