package Pages;

import org.openqa.selenium.WebDriver;
import Utils.Attendee;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static org.bouncycastle.oer.its.ieee1609dot2.basetypes.Duration.seconds;

public class BasePage {

    protected WebDriver driver = Attendee.getDriver();
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));


    protected void click(WebElement element) {
        waitForElementToBeClickable(element);
        element.click();
    }

    public void waitForElementToBeClickable(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitForElementToBeVisible(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    protected void type(WebElement element, String text) {
        click(element);
        element.sendKeys(text);

    }
}
