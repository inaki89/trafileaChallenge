package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static Utils.Attendee.driver;

public class MenuPage extends BasePage {

    @FindBy(xpath = "//*[@id=\"justuno_form\"]/div/div[2]/div[6]/div")
    private WebElement publicidadDescuento;
    @FindBy(xpath = "//*[@id=\"__next\"]/div/main/div[3]/h3")
    private WebElement OurBestSellers;
    @FindBy(xpath = "//*[@id=\"__next\"]/div/main/div[3]/div[3]/div[1]/div[4]//div/a[1]")
    private WebElement producto;

    public MenuPage(){
        PageFactory.initElements(driver, this);
    }

    public void seDirreccionaALaCompra(){
        click(publicidadDescuento);
        waitForElementToBeVisible(OurBestSellers);
        click(producto);
    }
}
