package enums;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import Utils.Attendee;

public class Hooks {

    public static Attendee attendee;
    private static ExtentReports extent;
    private static ExtentTest extentTest;

    public static void setAttendee(Attendee attendee) {
        Hooks.attendee = attendee;
    }


    @Before
    public void beforeScenario(Scenario scenario){
        System.out.println("browser: " + attendee.getProperty("trafilea.driver.browser"));
        attendee.configBrowser(attendee.getProperty("trafilea.driver.browser"), Boolean.parseBoolean(attendee.getProperty("trafilea.driver.headless")));
        extentTest = extent.createTest(scenario.getName());
    }

}
