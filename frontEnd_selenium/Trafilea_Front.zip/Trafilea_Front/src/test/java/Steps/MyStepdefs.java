package Steps;

import Pages.MenuPage;
import Utils.Attendee;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import static Utils.Attendee.*;

public class MyStepdefs {
    Attendee attendee = new Attendee();
    private MenuPage menuPage;

    public MyStepdefs() {
        System.out.println("Iniciando constructor de MyStepdefs...");
        try {
            // Inicializa attendee según tus necesidades
            attendee = getInstance();
            System.out.println("attendee inicializado");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Given("El usuario ingresa a la url establecida")
    public void el_usuario_ingresa_a_la_url_establecida() {
        if (attendee != null) {
            openPage(attendee.getProperty("trafilea.driver.url"));
        } else {
            System.out.println("attendee no inicializado correctamente");
            // Maneja la situación de que attendee no esté inicializado
        }
    }

    @When("Se direcciona a la seccion Our Best Sellers")
    public void se_direcciona_a_la_seccion_our_best_sellers() {
        if (menuPage == null) {
            // Inicializa menuPage según tus necesidades
            menuPage = new MenuPage();
        }
        menuPage.seDirreccionaALaCompra();
    }
}